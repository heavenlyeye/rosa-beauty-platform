from sqlalchemy.orm import Session
from sqlalchemy import and_
from typing import List, Optional
from ..models.service import Service, ServiceCategory
from ..schemas.service import ServiceCreate, ServiceRead

class ServiceService:
    def __init__(self, db: Session):
        self.db = db
    
    def create_service(self, service_data: ServiceCreate, salon_id: int) -> Service:
        """ایجاد خدمت جدید"""
        
        # بررسی وجود خدمت با همین نام در سالن
        existing = self.db.query(Service).filter(
            and_(
                Service.name == service_data.name,
                Service.salon_id == salon_id
            )
        ).first()
        
        if existing:
            raise ValueError("خدمت با این نام قبلاً در سالن ثبت شده است")
        
        # ایجاد خدمت جدید
        db_service = Service(
            name=service_data.name,
            description=service_data.description,
            category=service_data.category,
            price=service_data.price,
            discount_price=service_data.discount_price,
            duration_minutes=service_data.duration_minutes,
            is_available=service_data.is_available,
            requires_appointment=service_data.requires_appointment,
            salon_id=salon_id
        )
        
        self.db.add(db_service)
        self.db.commit()
        self.db.refresh(db_service)
        return db_service
    
    def get_services_by_salon(self, salon_id: int, category: Optional[ServiceCategory] = None) -> List[Service]:
        """دریافت خدمات یک سالن"""
        query = self.db.query(Service).filter(Service.salon_id == salon_id)
        
        if category:
            query = query.filter(Service.category == category)
        
        return query.all()
    
    def get_service_by_id(self, service_id: int, salon_id: int) -> Optional[Service]:
        """دریافت خدمت با ID"""
        return self.db.query(Service).filter(
            and_(Service.id == service_id, Service.salon_id == salon_id)
        ).first()
    
    def update_service(self, service_id: int, salon_id: int, service_data: dict) -> Optional[Service]:
        """بروزرسانی خدمت"""
        service = self.get_service_by_id(service_id, salon_id)
        if not service:
            return None
        
        for field, value in service_data.items():
            if hasattr(service, field) and value is not None:
                setattr(service, field, value)
        
        self.db.commit()
        self.db.refresh(service)
        return service
    
    def delete_service(self, service_id: int, salon_id: int) -> bool:
        """حذف خدمت"""
        service = self.get_service_by_id(service_id, salon_id)
        if not service:
            return False
        
        self.db.delete(service)
        self.db.commit()
        return True
    
    def get_categories(self) -> List[dict]:
        """دریافت لیست دسته‌بندی‌ها"""
        categories = [
            {"value": "hair_cut", "label": "کوتاهی مو"},
            {"value": "hair_color", "label": "رنگ مو"},
            {"value": "facial", "label": "پاکسازی پوست"},
            {"value": "makeup", "label": "آرایش"},
            {"value": "nail", "label": "ناخن"},
            {"value": "massage", "label": "ماساژ"},
            {"value": "eyebrow", "label": "ابرو"},
            {"value": "hair_treatment", "label": "درمان مو"},
            {"value": "skin_care", "label": "مراقبت پوست"},
            {"value": "other", "label": "سایر"}
        ]
        return categories
    
    def get_available_services(self, salon_id: int) -> List[Service]:
        """دریافت خدمات فعال یک سالن"""
        return self.db.query(Service).filter(
            and_(
                Service.salon_id == salon_id,
                Service.is_available == True
            )
        ).all()
    
    def search_services(self, salon_id: int, query: str) -> List[Service]:
        """جستجو در خدمات"""
        if not query or len(query) < 2:
            return []
        
        return self.db.query(Service).filter(
            and_(
                Service.salon_id == salon_id,
                Service.name.ilike(f"%{query}%")
            )
        ).all()
    
    def toggle_service_availability(self, service_id: int, salon_id: int) -> Optional[Service]:
        """تغییر وضعیت فعال/غیرفعال خدمت"""
        service = self.get_service_by_id(service_id, salon_id)
        if not service:
            return None
        
        service.is_available = not service.is_available
        self.db.commit()
        self.db.refresh(service)
        return service